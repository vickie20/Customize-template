module.exports = {
    content: ["./*.{php,html,js}"],
    theme: {
      extend: {},
    },
    plugins: [],
  }